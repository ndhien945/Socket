#pragma once
#include "Date.h"

class DateKeyboardProvider{
public:
    tuple<bool, int, string, Date*> inputString(string prompt);
    Date next(string prompt);
};