#include "DateKeyboardProvider.h"

tuple<bool, int, string, Date*> DateKeyboardProvider::inputString(string prompt){
    //initialize variable
    bool success = true;
    int code = 0;
    string message = "";
    Date* data = nullptr;
    
    cout << prompt << endl;
    string buffer;
    getline(cin, buffer);
    
    //check empty buffer
    if (buffer.empty()){
        message = "Input string cannot be empty.";
        return make_tuple(false, 1, message, nullptr);
    } else {
        regex datePattern("\\d+/\\d+/\\d+");
        bool matched = regex_match(buffer, datePattern);
        
        if ( matched == false) {
           message = "The string has incorrect format d/m/yyyy";
           return make_tuple(false, 2, message, nullptr); 
        }
        
        int day, month, year;
        stringstream ss(buffer);
        string temp_val;
        getline(ss, temp_val, '/');
        day = stoi(temp_val);
        getline(ss, temp_val, '/');
        month = stoi(temp_val);
        getline(ss, temp_val);
        year = stoi(temp_val);
        
        if (year <= 0){
            message = "Year value must be greater than 0.";
            return make_tuple(false, 3, message, nullptr); 
        } else {
            if (month > 12 || month < 1){
                message = "Month value must be belong to the range of [1, 12].";
                return make_tuple(false, 4, message, nullptr); 
            } else {
                bool leapYearFlag = false;
                if ((year % 400 == 0) || (year % 100 != 0) && (year % 4 == 0)){
                    leapYearFlag = true;
                }
                if (month == 2){
                    if (day >= 30){
                        message = "The inputted February's day is invalid.";
                        return make_tuple(false, 5, message, nullptr);
                    } else if (day == 29 && leapYearFlag == false){
                        message = "The day value must be <= 28 if the month is February and the year is leap.";
                        return make_tuple(false, 5, message, nullptr);
                    }
                } else if (month == 4 || month == 6 || month == 9 || month == 11){
                    if (day < 1 || day > 30) {
                        message = "Day value must be belong to the range of [1, 30] with corresspondingly inputted month.";
                        return make_tuple(false, 5, message, nullptr);
                    }
                } else {
                    if (day < 1 || day > 31) {
                        message = "Day value must be belong to the range of [1, 31] with corresspondingly inputted month.";
                        return make_tuple(false, 5, message, nullptr);
                    }
                }
            }
        }
        Date* d = new Date(day, month, year);
        return make_tuple(true, 0, message, d);
    }
    return make_tuple(false, 0, "", nullptr);
    
    
    
}

Date DateKeyboardProvider::next(string prompt){
    DateKeyboardProvider provider;
    auto[success, code, message, data] = provider.inputString(prompt);
    if (success){
        return *data; 
    } else {
        cout << "Cannot create a date. The reason: " << message << endl;
    }
    return Date(0,0,0);
}