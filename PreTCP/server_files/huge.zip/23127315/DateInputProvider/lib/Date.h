#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <regex>
#include <tuple>
using namespace std;

class Date{
private:
    int _day;
    int _month;
    int _year;
public:
    int day();
    int month();
    int year();
    Date();
    Date(int day, int month, int year);
};