#pragma once
#include "Date.h"

class DateToStringConverter{
public:
    string convert(Date d);
};