#include "DateToStringConverter.h"


string DateToStringConverter::convert(Date d){
    stringstream builder;
    builder << setw(2) << setfill('0') << d.day() << "/";
    builder << setw(2) << setfill('0') << d.month() << "/";
    builder << d.year();
    return builder.str();
}
