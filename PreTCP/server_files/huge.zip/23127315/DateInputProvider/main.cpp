#include "./lib/Date.h"
#include "./lib/DateKeyboardProvider.h"
#include "./lib/DateToStringConverter.h"


int main(){
    DateKeyboardProvider provider;
	Date d = provider.next("Enter your birthday");
	
	DateToStringConverter converter;
	cout << "You have entered: " << converter.convert(d);

	cout << "\n\n";


    

    return 0;
}