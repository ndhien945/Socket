#include "LineKeyboardProvider.h"

Line LineKeyboardProvider::next(string prompt){
    cout << prompt << endl;

    Point start, end;
    PointKeyboardProvider provider;
    start = provider.next("- Enter the start point.");

    end = provider.next("- Enter the end point.");
    

    return Line(start, end);
}