#pragma once

#include "Line.h"


using namespace std;

class LineKeyboardProvider{
public:
    Line next(string prompt);
};


