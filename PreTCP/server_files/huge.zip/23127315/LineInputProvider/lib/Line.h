#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

#include "../../PointInputProvider/lib/Point.h"
#include "../../PointInputProvider/lib/PointKeyboardProvider.h"
#include "../../PointInputProvider/lib/PointToStringConverter.h"


class Line{
private:
    Point _start;
    Point _end;
public:
    Point start();
    Point end();
    Line();
    Line(Point start, Point end);
};