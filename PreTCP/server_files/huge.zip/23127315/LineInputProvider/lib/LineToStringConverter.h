#pragma once
#include "Line.h"

using namespace std;

class LineToStringConverter{
public:
    string convert(Line l);
};