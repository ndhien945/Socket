#include "LineToStringConverter.h"

string LineToStringConverter::convert(Line l){
    stringstream builder;
    PointToStringConverter converter;
    Point start = l.start();
    Point end = l.end();
    builder << "(" << converter.convert(start) << ", " << converter.convert(end) << ")";

    return builder.str();
}
