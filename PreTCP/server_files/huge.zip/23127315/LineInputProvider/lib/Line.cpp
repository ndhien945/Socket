#include "Line.h"


Point Line::start(){
    return _start;
}
Point Line::end(){
    return _end;
}

Line::Line(){
    _start = Point();
    _end = Point();
}

Line::Line(Point start, Point end){
    _start = start;
    _end = end;
}