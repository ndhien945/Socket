#include "./lib/Line.h"
#include "./lib/LineKeyboardProvider.h"
#include "./lib/LineToStringConverter.h"


int main(){
    LineKeyboardProvider provider;
	Line l = provider.next("Enter a line.");
	LineToStringConverter converter;
	cout << "You have entered: " << converter.convert(l);
	cout << endl << endl;

    

    return 0;
}