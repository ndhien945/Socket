#include "./lib/Point.h"
#include "./lib/PointToStringConverter.h"
#include "./lib/PointKeyboardProvider.h"


int main(){
    PointKeyboardProvider provider;
	Point p = provider.next("Enter a point.");
	
	PointToStringConverter converter;
	cout << "You have entered: " << converter.convert(p);
    cout << endl << endl;


    

    return 0;
}