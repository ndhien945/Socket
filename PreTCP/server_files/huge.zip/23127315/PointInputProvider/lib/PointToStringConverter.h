#pragma once
#include "Point.h"

using namespace std;

class PointToStringConverter{
public:
    string convert(Point p);
};