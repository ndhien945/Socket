#include "PointKeyboardProvider.h"

Point PointKeyboardProvider::next(string prompt) {
    cout << prompt << endl;

    float x, y;
    cout << "\tx: ";
    cin >> x;
    cout << "\ty: ";
    cin >> y;

    return Point(x, y);
}