#include "PointToStringConverter.h"

string PointToStringConverter::convert(Point p){
    stringstream builder;
    builder << "(" << p.x() << ", " << p.y() << ")";

    return builder.str();
}
