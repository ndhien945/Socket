#pragma once
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class Point{
private:
    float _x;
    float _y;
public:
    Point();
    Point(float x, float y);
    float x();
    float y();
};