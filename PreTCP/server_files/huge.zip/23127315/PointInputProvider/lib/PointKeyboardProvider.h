#pragma once

#include "Point.h"


using namespace std;

class PointKeyboardProvider{
public:
    Point next(string prompt);
};


