Lớp: 23CLC04
Môn học: CSC10003 – Objected Oriented Programming
MSSV: 23127315
Họ và tên: Nguyễn Trần Thiên An

NOTE:
Vì em có phân ra mỗi file __InputProvider gồm 2 phần là main.cpp và folder lib nên cần thêm: 
    "*.cpp",
    "./lib/*.cpp",
vào trong phần "args" trong file tasks.json để compile được chương trình ạ.

Riêng folder LineInputProvider, em có sử dụng lại tất cả các file trong lib của folder PointInputProvider nên cần thêm:
    "../PointInputProvider/lib/*.cpp",
để chạy được chương trình trong folder LineInputProvider.